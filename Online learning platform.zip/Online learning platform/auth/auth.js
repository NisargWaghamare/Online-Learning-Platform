document.addEventListener('DOMContentLoaded', () => {
    // User Type Toggle
    const userTypeButtons = document.querySelectorAll('.user-type-toggle button');
    const teacherFields = document.getElementById('teacherFields');

    userTypeButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            userTypeButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
            
            // Show/hide teacher fields if on signup page
            if (teacherFields) {
                teacherFields.style.display = 
                    button.getAttribute('data-type') === 'teacher' ? 'block' : 'none';
            }
        });
    });

    // Password Visibility Toggle
    const passwordToggles = document.querySelectorAll('.password-toggle');
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            const input = toggle.previousElementSibling;
            const type = input.getAttribute('type');
            input.setAttribute('type', type === 'password' ? 'text' : 'password');
            toggle.classList.toggle('fa-eye');
            toggle.classList.toggle('fa-eye-slash');
        });
    });

    // Form Submission
    const form = document.querySelector('form');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        // Add user type
        data.userType = document.querySelector('.user-type-toggle button.active').getAttribute('data-type');
        
        try {
            // Show loading state
            const submitButton = form.querySelector('button[type="submit"]');
            const originalText = submitButton.textContent;
            submitButton.textContent = 'Please wait...';
            submitButton.disabled = true;

            // Simulate API call (replace with actual API endpoint)
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Store user data in localStorage (replace with proper authentication)
            localStorage.setItem('user', JSON.stringify(data));
            
            // Redirect to dashboard
            window.location.href = '../index.html';
            
        } catch (error) {
            console.error('Authentication error:', error);
            alert('An error occurred. Please try again.');
            
            // Reset button state
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }
    });

    // Social Login Handlers
    const socialButtons = document.querySelectorAll('.social-btn');
    socialButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Add actual social login implementation here
            alert('Social login feature coming soon!');
        });
    });

    // Password Validation (for signup)
    if (form.id === 'signupForm') {
        const password = form.querySelector('input[type="password"]');
        const confirmPassword = form.querySelectorAll('input[type="password"]')[1];
        
        function validatePassword() {
            if (password.value !== confirmPassword.value) {
                confirmPassword.setCustomValidity("Passwords don't match");
            } else {
                confirmPassword.setCustomValidity('');
            }
        }

        password.addEventListener('change', validatePassword);
        confirmPassword.addEventListener('keyup', validatePassword);
    }
});
