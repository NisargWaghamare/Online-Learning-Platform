from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)

# Sample data structure to store course information
courses = {
    'cs': {
        'name': 'Computer Science',
        'courses': [
            {
                'title': 'Programming Fundamentals',
                'description': 'Learn the basics of programming with Python, Java, and C++',
                'duration': '8 weeks',
                'level': 'Beginner'
            },
            {
                'title': 'Database Management',
                'description': 'Master SQL and NoSQL database concepts',
                'duration': '6 weeks',
                'level': 'Intermediate'
            }
        ]
    },
    'aids': {
        'name': 'AI & Data Science',
        'courses': [
            {
                'title': 'Machine Learning Basics',
                'description': 'Introduction to ML algorithms and implementations',
                'duration': '10 weeks',
                'level': 'Intermediate'
            }
        ]
    }
}

@app.route('/api/courses/<branch>')
def get_courses(branch):
    if branch in courses:
        return jsonify(courses[branch])
    return jsonify({'error': 'Branch not found'}), 404

@app.route('/api/search')
def search_courses():
    query = request.args.get('q', '').lower()
    results = []
    
    for branch in courses.values():
        for course in branch['courses']:
            if query in course['title'].lower() or query in course['description'].lower():
                results.append(course)
    
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
