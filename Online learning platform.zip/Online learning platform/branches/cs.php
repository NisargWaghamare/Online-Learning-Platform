<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Computer Science - Engineering Learning Hub</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            background-attachment: fixed;
        }

        .branch-header {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://source.unsplash.com/random/1920x1080/?coding');
            height: 50vh;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
            position: relative;
            margin-bottom: 3rem;
        }

        .branch-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            opacity: 0.8;
            animation: gradientFlow 10s ease infinite;
        }

        .branch-header h1 {
            font-size: 3rem;
            position: relative;
            z-index: 1;
            animation: glow 2s ease-in-out infinite alternate;
        }

        .course-content {
            padding: 2rem 5%;
            position: relative;
        }

        .course-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .course-card {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: all 0.3s ease;
            position: relative;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,255,255,0.2);
            animation: fadeIn 0.5s ease-out;
        }

        .course-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 15px 40px rgba(0,0,0,0.2);
        }

        .course-image {
            height: 200px;
            background-size: cover;
            background-position: center;
            position: relative;
            overflow: hidden;
        }

        .course-image::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, transparent, rgba(0,0,0,0.5));
        }

        .course-info {
            padding: 1.5rem;
            position: relative;
            z-index: 1;
        }

        .course-info h3 {
            color: #1e3c72;
            margin-bottom: 1rem;
            font-size: 1.5rem;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .course-info h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 2px;
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            transition: width 0.3s ease;
        }

        .course-card:hover .course-info h3::after {
            width: 100px;
        }

        .course-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1rem;
            color: #666;
        }

        .resource-link {
            display: inline-flex;
            align-items: center;
            padding: 0.8rem 1.5rem;
            background: linear-gradient(45deg, #ff0000, #cc0000);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(255,0,0,0.2);
        }

        .resource-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255,0,0,0.3);
            background: linear-gradient(45deg, #cc0000, #ff0000);
        }

        .resource-link i {
            margin-right: 0.5rem;
            font-size: 1.2rem;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Adding floating particles background */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }

        .particle {
            position: absolute;
            width: 5px;
            height: 5px;
            background: rgba(30,60,114,0.1);
            border-radius: 50%;
            animation: float 20s infinite linear;
        }

        @keyframes float {
            0% {
                transform: translateY(0) translateX(0);
            }
            100% {
                transform: translateY(-100vh) translateX(100vw);
            }
        }
    </style>
</head>
<body>
    <!-- Adding floating particles -->
    <div class="particles">
        <?php for($i = 0; $i < 50; $i++) { ?>
            <div class="particle" style="
                left: <?php echo rand(0, 100); ?>vw;
                top: <?php echo rand(0, 100); ?>vh;
                animation-delay: <?php echo rand(0, 20); ?>s;
                animation-duration: <?php echo rand(15, 30); ?>s;
            "></div>
        <?php } ?>
    </div>

    <nav>
        <div class="logo">
            <h1>Engineering Learning Hub</h1>
        </div>
        <ul class="nav-links">
            <li><a href="../index.html">Home</a></li>
            <li><a href="../index.html#branches">Branches</a></li>
            <li><a href="../index.html#resources">Resources</a></li>
            <li><a href="../index.html#contact">Contact</a></li>
        </ul>
    </nav>

    <div class="branch-header">
        <h1>Computer Science Engineering</h1>
    </div>

    <div class="course-content">
        <div class="course-grid">
            <div class="course-card">
                <div class="course-image" style="background-image: url('https://source.unsplash.com/random/400x300/?programming')"></div>
                <div class="course-info">
                    <h3>Programming Fundamentals</h3>
                    <p>Learn the basics of programming with Python, Java, and C++</p>
                    <div class="course-meta">
                        <span><i class="fas fa-clock"></i> 8 weeks</span>
                        <span><i class="fas fa-user-graduate"></i> Beginner</span>
                    </div>
                </div>
            </div>

            <div class="course-card">
                <div class="course-image" style="background-image: url('https://source.unsplash.com/random/400x300/?youtube-education')"></div>
                <div class="course-info">
                    <h3>CSE Concepts with Parinita</h3>
                    <p>Access comprehensive CS video tutorials and notes</p>
                    <div class="course-meta">
                        <span><i class="fas fa-video"></i> Video Content</span>
                        <a href="https://www.youtube.com/@CSEconceptswithParinita" target="_blank" class="resource-link">
                            <i class="fab fa-youtube"></i> Watch Now
                        </a>
                    </div>
                </div>
            </div>

            <div class="course-card">
                <div class="course-image" style="background-image: url('https://source.unsplash.com/random/400x300/?database')"></div>
                <div class="course-info">
                    <h3>Database Management</h3>
                    <p>Master SQL and NoSQL database concepts</p>
                    <div class="course-meta">
                        <span><i class="fas fa-clock"></i> 6 weeks</span>
                        <span><i class="fas fa-user-graduate"></i> Intermediate</span>
                    </div>
                </div>
            </div>

            <div class="course-card">
                <div class="course-image" style="background-image: url('https://source.unsplash.com/random/400x300/?algorithm')"></div>
                <div class="course-info">
                    <h3>Data Structures & Algorithms</h3>
                    <p>Learn essential algorithms and problem-solving techniques</p>
                    <div class="course-meta">
                        <span><i class="fas fa-clock"></i> 10 weeks</span>
                        <span><i class="fas fa-user-graduate"></i> Advanced</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h3>Contact Us</h3>
                <p>Email: info@engineeringhub.com</p>
                <p>Phone: +1 234 567 890</p>
            </div>
            <div class="footer-section">
                <h3>Follow Us</h3>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Engineering Learning Hub. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
