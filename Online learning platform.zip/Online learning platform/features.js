// Dark Mode Toggle
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
    updateDarkModeIcon();
}

function updateDarkModeIcon() {
    const icon = document.querySelector('.dark-mode-toggle i');
    if (document.body.classList.contains('dark-mode')) {
        icon.className = 'fas fa-sun';
    } else {
        icon.className = 'fas fa-moon';
    }
}

// Initialize dark mode from localStorage
document.addEventListener('DOMContentLoaded', () => {
    const darkMode = localStorage.getItem('darkMode') === 'true';
    if (darkMode) {
        document.body.classList.add('dark-mode');
        updateDarkModeIcon();
    }
});

// Progress Tracking
class ProgressTracker {
    constructor() {
        this.progress = JSON.parse(localStorage.getItem('courseProgress')) || {};
    }

    markComplete(courseId) {
        this.progress[courseId] = true;
        this.saveProgress();
        this.updateUI();
    }

    markIncomplete(courseId) {
        delete this.progress[courseId];
        this.saveProgress();
        this.updateUI();
    }

    saveProgress() {
        localStorage.setItem('courseProgress', JSON.stringify(this.progress));
    }

    updateUI() {
        const cards = document.querySelectorAll('.branch-card');
        cards.forEach(card => {
            const courseId = card.getAttribute('data-course-id');
            const progressBadge = card.querySelector('.progress-badge');
            if (this.progress[courseId]) {
                progressBadge.textContent = 'Completed';
                progressBadge.classList.add('completed');
            } else {
                progressBadge.textContent = 'In Progress';
                progressBadge.classList.remove('completed');
            }
        });
    }
}

// Initialize Progress Tracker
const progressTracker = new ProgressTracker();

// Quick Access Menu
function toggleQuickAccess() {
    const menu = document.querySelector('.quick-access-menu');
    menu.classList.toggle('quick-access-active');
}

// Interactive Roadmap
function initializeRoadmap() {
    const roadmapSteps = document.querySelectorAll('.roadmap-step');
    roadmapSteps.forEach((step, index) => {
        step.addEventListener('click', () => {
            const content = step.querySelector('.roadmap-content');
            content.style.display = content.style.display === 'none' ? 'block' : 'none';
            
            // Update connection lines
            const line = step.querySelector('.connection-line');
            if (line) {
                line.classList.toggle('active');
            }
        });

        // Add hover effect
        step.addEventListener('mouseenter', () => {
            step.classList.add('roadmap-step-hover');
        });

        step.addEventListener('mouseleave', () => {
            step.classList.remove('roadmap-step-hover');
        });
    });
}

// Search Functionality
function initializeSearch() {
    const searchInput = document.querySelector('.search-input');
    const searchResults = document.querySelector('.search-results');

    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const cards = document.querySelectorAll('.branch-card, .resource-item');
        
        searchResults.innerHTML = '';
        if (query.length > 2) {
            searchResults.style.display = 'block';
            cards.forEach(card => {
                const title = card.querySelector('h3').textContent.toLowerCase();
                const description = card.querySelector('p').textContent.toLowerCase();
                
                if (title.includes(query) || description.includes(query)) {
                    const result = document.createElement('div');
                    result.className = 'search-result-item';
                    result.innerHTML = `
                        <h4>${card.querySelector('h3').textContent}</h4>
                        <p>${card.querySelector('p').textContent}</p>
                    `;
                    result.addEventListener('click', () => {
                        card.scrollIntoView({ behavior: 'smooth' });
                        searchResults.style.display = 'none';
                        searchInput.value = '';
                    });
                    searchResults.appendChild(result);
                }
            });
        } else {
            searchResults.style.display = 'none';
        }
    });
}

// Initialize all features
document.addEventListener('DOMContentLoaded', () => {
    initializeRoadmap();
    initializeSearch();
    progressTracker.updateUI();
});
