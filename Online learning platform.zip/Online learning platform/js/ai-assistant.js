class AIAssistant {
    constructor() {
        this.context = [];
        this.isProcessing = false;
        this.initializeAssistant();
    }

    initializeAssistant() {
        // Create and append AI assistant HTML
        const assistantHTML = `
            <div class="ai-assistant">
                <div class="ai-toggle">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="ai-window">
                    <div class="ai-header">
                        <div class="ai-title">
                            <i class="fas fa-robot"></i>
                            <h3>AI Learning Assistant</h3>
                        </div>
                        <div class="ai-actions">
                            <button class="ai-feedback" title="Give feedback">
                                <i class="fas fa-star"></i>
                            </button>
                            <button class="ai-clear" title="Clear chat">
                                <i class="fas fa-broom"></i>
                            </button>
                            <button class="ai-minimize" title="Minimize">
                                <i class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="ai-chat">
                        <div class="ai-messages"></div>
                        <div class="ai-suggestions">
                            <button>How do I get started?</button>
                            <button>Recommend a learning path</button>
                            <button>Technical help</button>
                            <button>Course information</button>
                        </div>
                        <div class="ai-input">
                            <textarea placeholder="Ask me anything about learning, courses, or technical concepts..." rows="1"></textarea>
                            <button class="ai-send" title="Send message">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="feedback-modal">
                    <div class="feedback-content">
                        <div class="feedback-header">
                            <h3>How was your experience?</h3>
                            <button class="close-feedback">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="rating-stars">
                            <i class="far fa-star" data-rating="1"></i>
                            <i class="far fa-star" data-rating="2"></i>
                            <i class="far fa-star" data-rating="3"></i>
                            <i class="far fa-star" data-rating="4"></i>
                            <i class="far fa-star" data-rating="5"></i>
                        </div>
                        <textarea placeholder="Tell us about your experience (optional)"></textarea>
                        <button class="submit-feedback">Submit Feedback</button>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', assistantHTML);
        this.bindEvents();
        this.addWelcomeMessage();
    }

    bindEvents() {
        // Toggle AI window
        document.querySelector('.ai-toggle').addEventListener('click', () => {
            document.querySelector('.ai-window').classList.toggle('ai-window-active');
            document.querySelector('.ai-toggle').classList.toggle('ai-toggle-active');
        });

        // Minimize AI window
        document.querySelector('.ai-minimize').addEventListener('click', () => {
            document.querySelector('.ai-window').classList.remove('ai-window-active');
            document.querySelector('.ai-toggle').classList.remove('ai-toggle-active');
        });

        // Clear chat
        document.querySelector('.ai-clear').addEventListener('click', () => {
            document.querySelector('.ai-messages').innerHTML = '';
            this.addWelcomeMessage();
        });

        // Handle suggestions
        document.querySelectorAll('.ai-suggestions button').forEach(button => {
            button.addEventListener('click', () => {
                this.handleUserInput(button.textContent);
            });
        });

        // Handle user input
        const textarea = document.querySelector('.ai-input textarea');
        const sendButton = document.querySelector('.ai-send');

        // Auto-resize textarea
        textarea.addEventListener('input', () => {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        });

        // Send message on enter (but allow new line with shift+enter)
        textarea.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.handleUserInput(textarea.value);
            }
        });

        // Send message on button click
        sendButton.addEventListener('click', () => {
            this.handleUserInput(textarea.value);
        });

        // Feedback modal events
        const feedbackBtn = document.querySelector('.ai-feedback');
        const feedbackModal = document.querySelector('.feedback-modal');
        const closeFeedbackBtn = document.querySelector('.close-feedback');
        const stars = document.querySelectorAll('.rating-stars i');
        const submitFeedbackBtn = document.querySelector('.submit-feedback');

        feedbackBtn.addEventListener('click', () => {
            feedbackModal.classList.add('show-feedback');
        });

        closeFeedbackBtn.addEventListener('click', () => {
            feedbackModal.classList.remove('show-feedback');
            this.resetFeedbackForm();
        });

        stars.forEach(star => {
            star.addEventListener('mouseover', () => {
                const rating = star.dataset.rating;
                this.updateStars(rating, 'hover');
            });

            star.addEventListener('mouseout', () => {
                this.updateStars(0, 'hover');
            });

            star.addEventListener('click', () => {
                const rating = star.dataset.rating;
                this.updateStars(rating, 'selected');
            });
        });

        submitFeedbackBtn.addEventListener('click', () => {
            const rating = document.querySelectorAll('.rating-stars i.fas').length;
            const comment = document.querySelector('.feedback-modal textarea').value;
            this.submitFeedback(rating, comment);
        });

        // Close modal if clicking outside
        feedbackModal.addEventListener('click', (e) => {
            if (e.target === feedbackModal) {
                feedbackModal.classList.remove('show-feedback');
                this.resetFeedbackForm();
            }
        });
    }

    addWelcomeMessage() {
        const welcomeMessage = {
            type: 'assistant',
            content: "Hello! I'm your AI Learning Assistant. I can help you with course recommendations, technical concepts, learning paths, and more. How can I assist you today?"
        };
        this.addMessageToChat(welcomeMessage);
    }

    async handleUserInput(input) {
        if (!input.trim() || this.isProcessing) return;

        const textarea = document.querySelector('.ai-input textarea');
        textarea.value = '';
        textarea.style.height = 'auto';

        // Add user message to chat
        this.addMessageToChat({ type: 'user', content: input });

        // Show typing indicator
        this.isProcessing = true;
        this.showTypingIndicator();

        try {
            // Get AI response based on input
            const response = await this.getAIResponse(input);
            
            // Remove typing indicator and add AI response
            this.removeTypingIndicator();
            this.addMessageToChat({ type: 'assistant', content: response });
        } catch (error) {
            console.error('Error getting AI response:', error);
            this.removeTypingIndicator();
            this.addMessageToChat({ 
                type: 'assistant', 
                content: "I apologize, but I'm having trouble processing your request. Please try again." 
            });
        }

        this.isProcessing = false;
    }

    addMessageToChat(message) {
        const messagesContainer = document.querySelector('.ai-messages');
        const messageElement = document.createElement('div');
        messageElement.className = `ai-message ${message.type}-message`;
        
        // Create message content
        const content = document.createElement('div');
        content.className = 'message-content';
        content.innerHTML = this.formatMessage(message.content);
        
        // Add avatar for assistant messages
        if (message.type === 'assistant') {
            const avatar = document.createElement('div');
            avatar.className = 'assistant-avatar';
            avatar.innerHTML = '<i class="fas fa-robot"></i>';
            messageElement.appendChild(avatar);
        }

        messageElement.appendChild(content);
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    formatMessage(content) {
        // Convert URLs to links
        content = content.replace(
            /(https?:\/\/[^\s]+)/g, 
            '<a href="$1" target="_blank">$1</a>'
        );

        // Convert code blocks
        content = content.replace(
            /`([^`]+)`/g,
            '<code>$1</code>'
        );

        // Convert bullet points
        content = content.replace(
            /^\s*[-*]\s+(.+)$/gm,
            '<li>$1</li>'
        );

        return content;
    }

    showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'ai-message assistant-message typing-indicator';
        indicator.innerHTML = `
            <div class="assistant-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="typing-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        `;
        document.querySelector('.ai-messages').appendChild(indicator);
    }

    removeTypingIndicator() {
        const indicator = document.querySelector('.typing-indicator');
        if (indicator) indicator.remove();
    }

    async getAIResponse(input) {
        // Simulate AI processing time
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Simple response logic (replace with actual AI integration)
        const normalizedInput = input.toLowerCase();
        
        if (normalizedInput.includes('get started')) {
            return `Here's how to get started:
            * Create an account or log in
            * Complete your profile
            * Browse available courses
            * Select your learning path
            * Start with beginner-friendly courses
            * Track your progress in the dashboard`;
        }
        
        if (normalizedInput.includes('learning path')) {
            return `I'll help you find the right learning path. Here are some popular paths:
            * Web Development (HTML, CSS, JavaScript)
            * Data Science (Python, Statistics, ML)
            * Mobile Development (Android/iOS)
            * Cloud Computing (AWS, Azure)
            * Cybersecurity
            
            Which area interests you the most?`;
        }
        
        if (normalizedInput.includes('technical help')) {
            return `I can help with technical questions about:
            * Programming languages
            * Development tools
            * Frameworks and libraries
            * Best practices
            * Debug common errors
            
            What specific technical help do you need?`;
        }
        
        if (normalizedInput.includes('course')) {
            return `Our courses are organized by:
            * Difficulty level (Beginner to Advanced)
            * Topic (Programming, Design, Data Science, etc.)
            * Duration (Short courses to Full programs)
            * Format (Video, Interactive, Project-based)
            
            Would you like me to recommend specific courses?`;
        }

        return `I'll do my best to help you with that. Could you please provide more details about what you're looking to learn or achieve? I can assist with:
        * Course recommendations
        * Learning paths
        * Technical concepts
        * Study strategies
        * Project ideas`;
    }

    updateStars(rating, state) {
        const stars = document.querySelectorAll('.rating-stars i');
        stars.forEach((star, index) => {
            if (state === 'hover') {
                star.classList.toggle('fas', index < rating);
                star.classList.toggle('far', index >= rating);
            } else if (state === 'selected') {
                star.classList.remove('far');
                star.classList.add('fas');
                if (index >= rating) {
                    star.classList.remove('fas');
                    star.classList.add('far');
                }
            }
        });
    }

    resetFeedbackForm() {
        const stars = document.querySelectorAll('.rating-stars i');
        const textarea = document.querySelector('.feedback-modal textarea');
        stars.forEach(star => {
            star.classList.remove('fas');
            star.classList.add('far');
        });
        textarea.value = '';
    }

    async submitFeedback(rating, comment) {
        // Here you would typically send the feedback to your server
        console.log('Feedback submitted:', { rating, comment });
        
        // Show success message
        const modal = document.querySelector('.feedback-modal');
        const content = document.querySelector('.feedback-content');
        content.innerHTML = `
            <div class="feedback-success">
                <i class="fas fa-check-circle"></i>
                <h3>Thank you for your feedback!</h3>
                <p>Your input helps us improve our service.</p>
                <button class="close-feedback">Close</button>
            </div>
        `;

        // Close modal after delay
        setTimeout(() => {
            modal.classList.remove('show-feedback');
            setTimeout(() => {
                this.resetFeedbackForm();
                content.innerHTML = this.getFeedbackFormHTML();
                this.bindEvents();
            }, 300);
        }, 2000);
    }

    getFeedbackFormHTML() {
        return `
            <div class="feedback-header">
                <h3>How was your experience?</h3>
                <button class="close-feedback">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="rating-stars">
                <i class="far fa-star" data-rating="1"></i>
                <i class="far fa-star" data-rating="2"></i>
                <i class="far fa-star" data-rating="3"></i>
                <i class="far fa-star" data-rating="4"></i>
                <i class="far fa-star" data-rating="5"></i>
            </div>
            <textarea placeholder="Tell us about your experience (optional)"></textarea>
            <button class="submit-feedback">Submit Feedback</button>
        `;
    }
}

// Initialize AI Assistant when document is ready
document.addEventListener('DOMContentLoaded', () => {
    window.aiAssistant = new AIAssistant();
});
