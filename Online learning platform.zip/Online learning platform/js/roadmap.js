document.addEventListener('DOMContentLoaded', () => {
    // Roadmap Path Switching
    const pathButtons = document.querySelectorAll('.roadmap-filters button');
    const paths = document.querySelectorAll('.roadmap-path');
    const progressValue = document.querySelector('.progress-value');
    const progressFill = document.querySelector('.progress-fill');
    const nextMilestone = document.querySelector('.progress-item:last-child .progress-value');

    pathButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Update active button
            pathButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // Show selected path
            const pathName = button.dataset.path;
            paths.forEach(path => {
                path.classList.remove('active');
                if (path.classList.contains(`${pathName}-path`)) {
                    path.classList.add('active');
                }
            });

            // Update progress information
            progressValue.textContent = button.textContent;
            progressFill.style.width = '0%';
            
            // Set next milestone based on path
            const milestones = {
                'web': 'Frontend Development',
                'data': 'Machine Learning Basics',
                'mobile': 'Native Development',
                'cloud': 'Container Orchestration'
            };
            nextMilestone.textContent = milestones[pathName] || 'Next Module';
        });
    });

    // Start Learning Button Interactions
    const startButtons = document.querySelectorAll('.start-learning');
    startButtons.forEach(button => {
        button.addEventListener('click', () => {
            const milestone = button.closest('.milestone-content').querySelector('h3').textContent;
            
            // Animate button
            button.style.transform = 'scale(0.95)';
            setTimeout(() => button.style.transform = '', 150);

            // Update progress (simulated)
            const currentProgress = parseInt(progressFill.style.width) || 0;
            const newProgress = Math.min(currentProgress + 25, 100);
            progressFill.style.width = `${newProgress}%`;

            // Show start message
            showStartMessage(milestone);
        });
    });

    function showStartMessage(milestone) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = 'toast-notification';
        toast.innerHTML = `
            <i class="fas fa-rocket"></i>
            <div class="toast-content">
                <h4>Starting: ${milestone}</h4>
                <p>Get ready to begin your learning journey!</p>
            </div>
        `;

        // Add toast to document
        document.body.appendChild(toast);

        // Trigger animation
        setTimeout(() => toast.classList.add('show'), 100);

        // Remove toast after delay
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Add toast notification styles if not already present
    if (!document.querySelector('#toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.textContent = `
            .toast-notification {
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: white;
                padding: 15px 25px;
                border-radius: 15px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                display: flex;
                align-items: center;
                gap: 15px;
                transform: translateY(100px);
                opacity: 0;
                transition: all 0.3s ease;
                z-index: 1000;
            }

            .toast-notification.show {
                transform: translateY(0);
                opacity: 1;
            }

            .toast-notification i {
                font-size: 24px;
                color: var(--primary-color);
            }

            .toast-content h4 {
                margin: 0;
                color: var(--primary-color);
            }

            .toast-content p {
                margin: 5px 0 0;
                color: #4b5563;
                font-size: 0.9rem;
            }
        `;
        document.head.appendChild(style);
    }
});
