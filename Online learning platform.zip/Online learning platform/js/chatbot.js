class Chatbot {
    constructor() {
        this.messages = [];
        this.responses = {
            'hello': 'Hi there! How can I help you today?',
            'hi': 'Hello! How can I assist you?',
            'courses': 'We offer various engineering courses. Which branch are you interested in?',
            'computer science': 'Our Computer Science program includes courses in programming, data structures, algorithms, and more. Check out our CS page for details!',
            'mechanical': 'Our Mechanical Engineering program covers thermodynamics, machine design, and manufacturing. Visit our ME page to learn more!',
            'ai': 'Our AI & Data Science program includes machine learning, deep learning, and data analytics courses.',
            'contact': 'You can reach us at support@engineeringlearninghub.com or through the contact form on our website.',
            'default': 'I apologize, I didn\'t quite understand that. Could you please rephrase or ask about our courses, branches, or contact information?'
        };
    }

    processMessage(message) {
        message = message.toLowerCase();
        let response = this.responses.default;
        
        for (let key in this.responses) {
            if (message.includes(key)) {
                response = this.responses[key];
                break;
            }
        }
        
        return response;
    }
}

// Initialize chatbot
const chatbot = new Chatbot();

function toggleChatbot() {
    const chatbox = document.querySelector('.chatbox');
    chatbox.classList.toggle('chatbox-hidden');
}

function sendMessage() {
    const input = document.querySelector('.chat-input');
    const message = input.value.trim();
    
    if (message) {
        const chatMessages = document.querySelector('.chat-messages');
        
        // Add user message
        const userMessage = document.createElement('div');
        userMessage.className = 'chat-message user-message';
        userMessage.textContent = message;
        chatMessages.appendChild(userMessage);
        
        // Get and add bot response
        const botResponse = chatbot.processMessage(message);
        const botMessage = document.createElement('div');
        botMessage.className = 'chat-message bot-message';
        botMessage.textContent = botResponse;
        
        // Add slight delay to bot response
        setTimeout(() => {
            chatMessages.appendChild(botMessage);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 500);
        
        input.value = '';
    }
}

// Handle enter key press
document.addEventListener('DOMContentLoaded', () => {
    const input = document.querySelector('.chat-input');
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});
