// Simple chatbot implementation
const responses = {
    'hello': 'Hi there! How can I help you today?',
    'hi': 'Hello! How can I assist you?',
    'hey': 'Hey! What can I do for you?',
    'courses': 'We offer various engineering courses including Computer Science, AI & Data Science, Mechanical, Electronics & Communication, and Electrical Engineering. Which branch interests you?',
    'computer': 'Our Computer Science program includes courses in:\n- Programming\n- Data Structures\n- Algorithms\n- Web Development\n- Database Management',
    'mechanical': 'Our Mechanical Engineering program covers:\n- Thermodynamics\n- Machine Design\n- Manufacturing\n- CAD/CAM\n- Fluid Mechanics',
    'electrical': 'Our Electrical Engineering program includes:\n- Power Systems\n- Control Systems\n- Electric Machines\n- Power Electronics',
    'electronics': 'Our Electronics & Communication program covers:\n- Circuit Theory\n- Digital Electronics\n- Communication Systems\n- Signal Processing',
    'ai': 'Our AI & Data Science program includes:\n- Machine Learning\n- Deep Learning\n- Data Analytics\n- Big Data\n- Neural Networks',
    'contact': 'You can reach us at:\nEmail: engineeringhubb.com\nPhone: +9353662156',
    'resources': 'We offer various learning resources including:\n- E-Books\n- Video Lectures\n- Practice Problems\n- Discussion Forums',
    'help': 'I can help you with:\n- Course Information\n- Branch Details\n- Learning Resources\n- Contact Information\nJust ask me about any of these topics!'
};

// Function to toggle chatbot visibility
function toggleChatbot() {
    const chatbox = document.querySelector('.chatbox');
    chatbox.classList.toggle('chatbox-hidden');
}

// Function to get bot response
function getBotResponse(userMessage) {
    userMessage = userMessage.toLowerCase();
    
    // Check for matching keywords
    for (let key in responses) {
        if (userMessage.includes(key)) {
            return responses[key];
        }
    }
    
    // Default response if no keyword matches
    return "I'm not sure about that. You can ask me about our courses, different engineering branches, learning resources, or contact information. Type 'help' to see what I can help you with!";
}

// Function to add message to chat
function addMessage(message, isUser = false) {
    const chatMessages = document.querySelector('.chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${isUser ? 'user-message' : 'bot-message'}`;
    messageDiv.textContent = message;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Function to handle sending messages
function sendMessage() {
    const input = document.querySelector('.chat-input');
    const message = input.value.trim();
    
    if (message) {
        // Add user message
        addMessage(message, true);
        
        // Get and add bot response
        setTimeout(() => {
            const botResponse = getBotResponse(message);
            addMessage(botResponse);
        }, 500);
        
        // Clear input
        input.value = '';
    }
}

// Event listener for enter key
document.addEventListener('DOMContentLoaded', () => {
    const input = document.querySelector('.chat-input');
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});
